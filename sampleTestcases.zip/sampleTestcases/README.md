This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

This project is a sample of how to use Jest and Enzyme to do unit tests with React.